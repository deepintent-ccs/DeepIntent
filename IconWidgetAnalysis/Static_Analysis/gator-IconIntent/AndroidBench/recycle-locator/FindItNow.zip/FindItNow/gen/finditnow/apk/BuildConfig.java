/** Automatically generated file. DO NOT MODIFY */
package finditnow.apk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}